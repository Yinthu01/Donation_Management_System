<?php
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input
    $first_name = !empty($_POST['first_name']) ? mysqli_real_escape_string($conn, $_POST['first_name']) : NULL;
    $last_name = !empty($_POST['last_name']) ? mysqli_real_escape_string($conn, $_POST['last_name']) : NULL;
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $donor_type = mysqli_real_escape_string($conn, $_POST['donor_type']);
    $organization_name = !empty($_POST['organization_name']) ? mysqli_real_escape_string($conn, $_POST['organization_name']) : NULL;

    // Prepare query based on whether first_name and last_name are provided
    $query = "INSERT INTO donors (email, phone, donor_type" .
             (!is_null($first_name) ? ", first_name" : "") .
             (!is_null($last_name) ? ", last_name" : "") .
             (!is_null($organization_name) ? ", organization_name" : "") .
             ") VALUES ('$email', '$phone', '$donor_type'" .
             (!is_null($first_name) ? ", '$first_name'" : "") .
             (!is_null($last_name) ? ", '$last_name'" : "") .
             (!is_null($organization_name) ? ", '$organization_name'" : "") .
             ")";

    if (mysqli_query($conn, $query)) {
        header("Location: manage_donors.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
$first_name = isset($_POST['first_name']) ? $_POST['first_name'] : null;
$last_name = isset($_POST['last_name']) ? $_POST['last_name'] : null;
$email = $_POST['email'];
$phone = $_POST['phone'];
$donor_type = $_POST['donor_type'];
$organization_name = isset($_POST['organization_name']) ? $_POST['organization_name'] : null;

// Prepare and execute SQL statement
