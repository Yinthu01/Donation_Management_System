<?php
include 'db.php';

// Fetch all events from the database
$query = "SELECT * FROM events ORDER BY event_date DESC";
$result = mysqli_query($conn, $query);

// Error handling
if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Event Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .navbar {
    background-color: #343a40;
    padding: 1rem;
}

.navbar-brand {
    color: #fff;
    font-size: 1.5rem;
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #ddd;
    margin-left: 20px;
    position: relative;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
}

/* Hover effect for normal nav links */
.navbar-nav .nav-link:hover {
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    transition: 0.3s;
}

/* Dropdown specific styling */
.navbar-nav .dropdown-menu {
    background-color: #444;
    border: none;
    border-radius: 10px;
    padding: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    margin-top: 10px;
}

.navbar-nav .dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
}

/* Dropdown item styling */
.navbar-nav .dropdown-item {
    color: #ddd;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

/* Hover effect for dropdown items */
.navbar-nav .dropdown-item:hover {
    background-color: #ff7f50;
    color: white;
    transform: scale(1.05);
}

/* Arrow styling for the dropdown toggle */
.navbar-nav .dropdown-toggle::after {
    display: none;
}

.navbar-nav .dropdown-toggle:after {
    content: '\25BC'; /* Unicode for a down arrow */
    margin-left: 5px;
    font-size: 0.8rem;
    color: #ddd;
    transition: transform 0.3s ease;
}

/* Rotate arrow when dropdown is open */
.navbar-nav .dropdown-toggle[aria-expanded="true"]::after {
    transform: rotate(180deg);
}

body {
    display: flex;
    flex-direction: column;
}

.content-wrapper {
    flex: 1;
    padding-bottom: 20px; /* Optional: Add some spacing before the footer */
}
        h2 {
            color: #343a40;
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
        }
        .event-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .event-header h2 {
            font-size: 1.8rem;
            font-weight: bold;
            text-align: center;
            text-align: center;
        }
        .event-table th, .event-table td {
            text-align: center;
        }
        .event-table .btn {
            padding: 5px 10px;
        }
        .modal-header {
            background-color: #343a40;
            color: white;
        }
        .modal-footer .btn {
            border-radius: 30px;
        }
        .table th {
            background-color: #007bff; /* Primary color for header */
            color: #ffffff; /* White text color */
            font-weight: bold; /* Bold header text */
            padding: 12px; /* Add padding to header cells */
        }
        .btn-add-event {
            background-color: #28a745;
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            color: white;
        }
        .btn-add-event:hover {
            background-color: #218838;
        }
        .btn-edit {
            background-color: #ffc107;
            border: none;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
            border: none;
            color: white;
        }
        .footer {
            background-color: #343a40;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
            width: 100%;
            margin-top: auto;/* Ensure space between content and footer */
        }
        .footer-links {
            margin-top: 10px;
        }
        .footer-links a {
            color: #ddd;
            margin: 0 10px;
            text-decoration: none;
        }
        .footer-links a:hover {
            color: #fff;
            transition: 0.3s;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-hands-helping"></i> Charity Management</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_donors.php"><i class="fas fa-users"></i> Donors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php"><i class="fas fa-hand-holding-usd"></i> Donations</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-calendar-alt"></i> More
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="event.php">Event</a></li>
                        <li><a class="dropdown-item" href="volunteer.php">Volunteer</a></li>
                        <li><a class="dropdown-item" href="event_volunteers.php">Volunteer_event</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>



<!-- Main container -->
<div class="container mt-5">
    <div class="event-header">
        <h2>Manage Events</h2>
        <button class="btn btn-add-event" data-bs-toggle="modal" data-bs-target="#addEventModal">
            <i class="fas fa-plus"></i> Add Event
        </button>
    </div>

    <!-- Event Table -->
    <table class="table table-bordered table-striped event-table">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Event Name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Location</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($result) > 0):
                while($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($row['event_id']); ?></td>
                <td><?php echo htmlspecialchars($row['event_name']); ?></td>
                <td><?php echo htmlspecialchars($row['event_date']); ?></td>
                <td><?php echo htmlspecialchars($row['event_time']); ?></td>
                <td><?php echo htmlspecialchars($row['location']); ?></td>
                <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                <td>
                    <button class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#editEventModal" 
                        data-id="<?php echo htmlspecialchars($row['event_id']); ?>"
                        data-name="<?php echo htmlspecialchars($row['event_name']); ?>"
                        data-date="<?php echo htmlspecialchars($row['event_date']); ?>"
                        data-time="<?php echo htmlspecialchars($row['event_time']); ?>"
                        data-location="<?php echo htmlspecialchars($row['location']); ?>"><i class="fas fa-edit"></i></button>
                    <a href="delete_event.php?id=<?php echo htmlspecialchars($row['event_id']); ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this event?');"><i class="fas fa-trash-alt"></i></a>
                </td>
            </tr>
            <?php
                endwhile;
            else:
            ?>
            <tr>
                <td colspan="7">No events found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>



<!-- Add Event Modal -->
<div class="modal fade" id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventModalLabel">Add Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="add_event.php" method="POST">
                    <div class="mb-3">
                        <label for="event_name" class="form-label">Event Name</label>
                        <input type="text" class="form-control" id="event_name" name="event_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="event_description" class="form-label">Event Description</label>
                        <textarea class="form-control" id="event_description" name="event_description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="event_date" class="form-label">Event Date</label>
                        <input type="date" class="form-control" id="event_date" name="event_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="event_time" class="form-label">Event Time</label>
                        <input type="time" class="form-control" id="event_time" name="event_time">
                    </div>
                    <div class="mb-3">
                        <label for="event_location" class="form-label">Event Location</label>
                        <input type="text" class="form-control" id="event_location" name="event_location" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add Event</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Event Modal -->
<div class="modal fade" id="editEventModal" tabindex="-1" aria-labelledby="editEventModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editEventModalLabel">Edit Event</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="edit_event.php" method="POST">
                    <input type="hidden" id="edit_event_id" name="event_id">
                    <div class="mb-3">
                        <label for="edit_event_name" class="form-label">Event Name</label>
                        <input type="text" class="form-control" id="edit_event_name" name="event_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_event_date" class="form-label">Event Date</label>
                        <input type="date" class="form-control" id="edit_event_date" name="event_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_event_time" class="form-label">Event Time</label>
                        <input type="time" class="form-control" id="edit_event_time" name="event_time">
                    </div>
                    <div class="mb-3">
                        <label for="edit_event_location" class="form-label">Event Location</label>
                        <input type="text" class="form-control" id="edit_event_location" name="event_location" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Update Event</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
        <p>&copy; 2024 Charity Management. All Rights Reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a> | <a href="#">Contact Us</a>
        </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', function() {
        let eventId = this.getAttribute('data-id');
        let eventName = this.getAttribute('data-name');
        let eventDate = this.getAttribute('data-date');
        let eventTime = this.getAttribute('data-time');
        let eventLocation = this.getAttribute('data-location');

        document.getElementById('edit_event_id').value = eventId;
        document.getElementById('edit_event_name').value = eventName;
        document.getElementById('edit_event_date').value = eventDate;
        document.getElementById('edit_event_time').value = eventTime;
        document.getElementById('edit_event_location').value = eventLocation;
    });
});
</script>

</body>
</html>
