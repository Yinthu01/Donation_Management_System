// Donor Registration Form Submission
document.getElementById('donorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let firstName = document.getElementById('firstName').value;
    let lastName = document.getElementById('lastName').value;
    let email = document.getElementById('email').value;
    let phone = document.getElementById('phone').value;

    console.log("Donor Registered: ", firstName, lastName, email, phone);
    alert('Donor Registered Successfully!');
    document.getElementById('donorForm').reset();
});

// Donation Form Submission
document.getElementById('donationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let donorId = document.getElementById('donorId').value;
    let donationAmount = document.getElementById('donationAmount').value;
    let donationType = document.getElementById('donationType').value;

    console.log("Donation Recorded: ", donorId, donationAmount, donationType);
    alert('Donation Recorded Successfully!');
    document.getElementById('donationForm').reset();
});

// Event Planning Form Submission
document.getElementById('eventForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let eventName = document.getElementById('eventName').value;
    let eventDate = document.getElementById('eventDate').value;
    let eventLocation = document.getElementById('eventLocation').value;

    console.log("Event Planned: ", eventName, eventDate, eventLocation);
    alert('Event Planned Successfully!');
    document.getElementById('eventForm').reset();
});
