<?php
include 'db.php';

if (isset($_GET['id'])) {
    $volunteer_id = $_GET['id'];

    $query = "DELETE FROM volunteers WHERE volunteer_id = $volunteer_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        header("Location: volunteer.php");
    } else {
        die("Delete query failed: " . mysqli_error($conn));
    }
}
?>
