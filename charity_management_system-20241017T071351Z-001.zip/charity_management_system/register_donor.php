<?php
session_start();
include 'db.php'; // Ensure this path is correct

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $donor_type = $conn->real_escape_string($_POST['donor_type']);
    
    // Insert donor information into the database
    $sql = "INSERT INTO donors (first_name, last_name, email, phone, donor_type) VALUES ('$first_name', '$last_name', '$email', '$phone', '$donor_type')";
    
    // Execute the statement
    if ($conn->query($sql) === TRUE) {
        // Get the last inserted donor_id
        $donor_id = $conn->insert_id;
        
        // Store the donor_id in a session variable
        $_SESSION['donor_id'] = $donor_id;
        
        // Redirect to register_donations.php
        header("Location: register_donations.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #9FE2BF;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-top: 50px;
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 10px;
            font-weight: bold;
        }
        input, select {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .message {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Donor Registration</h1>


        <form action="" method="POST">
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required>

            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone">

            <label for="donor_type">Donor Type:</label>
            <select id="donor_type" name="donor_type" required>
                <option value="individual">Individual</option>
                <option value="organization">Organization</option>
            </select>

            <label for="organization_name">Organization Name:</label>
            <input type="text" id="organization_name" name="organization_name">

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
