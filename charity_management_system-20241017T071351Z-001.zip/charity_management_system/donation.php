<?php
session_start();
include 'db.php'; 
$result = $conn->query("SELECT * FROM donations"); // Include the database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Donations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Similar styles from manage_donors.php */
        /* Navbar Styling */
.navbar {
    background-color: #343a40;
    padding: 1rem;
}

.navbar-brand {
    color: #fff;
    font-size: 1.5rem;
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #ddd;
    margin-left: 20px;
    position: relative;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
}

/* Hover effect for normal nav links */
.navbar-nav .nav-link:hover {
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    transition: 0.3s;
}

/* Dropdown specific styling */
.navbar-nav .dropdown-menu {
    background-color: #444;
    border: none;
    border-radius: 10px;
    padding: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    margin-top: 10px;
}

.navbar-nav .dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
}

/* Dropdown item styling */
.navbar-nav .dropdown-item {
    color: #ddd;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

/* Hover effect for dropdown items */
.navbar-nav .dropdown-item:hover {
    background-color: #ff7f50;
    color: white;
    transform: scale(1.05);
}

/* Arrow styling for the dropdown toggle */
.navbar-nav .dropdown-toggle::after {
    display: none;
}

.navbar-nav .dropdown-toggle:after {
    content: '\25BC'; /* Unicode for a down arrow */
    margin-left: 5px;
    font-size: 0.8rem;
    color: #ddd;
    transition: transform 0.3s ease;
}

/* Rotate arrow when dropdown is open */
.navbar-nav .dropdown-toggle[aria-expanded="true"]::after {
    transform: rotate(180deg);
}

        .page-header {
            background-color: #f8f9fa;
            padding: 30px;
            text-align: center;
        }
        .page-header h1 {
            color: #343a40;
            font-weight: bold;
            margin-bottom: 10px;
            margin-top: 20px;
        }
        .page-header p {
            color: #6c757d;
            font-size: 1.2rem;
        }
        .container {
            text-align: center;
            margin-bottom: 1px; /* Space between table and footer */
        }
        .btn-add {
            background: linear-gradient(135deg, #28a745, #218838);
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }
        .btn-add:hover {
            background: linear-gradient(135deg, #218838, #28a745);
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        .btn-add {
            padding: 8px 16px; /* Adjust padding if needed */
            margin-right: 80px;
        }
        .btn-edit, .btn-delete {
            border: none;
            color: white;
            font-size: 0.9rem;
            border-radius: 5px;
            padding: 5px 10px;
            transition: all 0.3s ease;
        }
        .btn-edit {
            background-color: #28a745;
        }
        .btn-edit:hover {
            background-color: #218838;
        }
        .btn-delete {
            background-color: #dc3545;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
        html, body {
    height: 100%;
    margin: 0;
    }

    body {
    overflow-y: auto; /* Enable vertical scrolling */
    }

/* Optional: Add padding to body if needed */
    body {
    padding-bottom: 80px; /* Space for footer */
    }

    .container {
    padding-bottom: 1px; /* Ensure space for footer */
    }
        .table-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            margin-top: 20px; /* Space between button and table */
            overflow-y: auto; /* Allow horizontal scrolling */
            max-height: calc(100vh - 100px);
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
            width: 100%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* 3D effect */
            table-layout: fixed; /* Ensure table fits within container */
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
        .table thead th {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 1px;
            text-align: center;
            bottom: 0;
            width: 100%;
            margin-top: 200px; /* Ensure space between content and footer */
        }
        .footer-links {
            margin-top: 10px;
        }
        .footer-links a {
            color: #ddd;
            margin: 0 10px;
            text-decoration: none;
        }
        .footer-links a:hover {
            color: #fff;
            transition: 0.3s;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-hands-helping"></i> Charity Management</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_donors.php"><i class="fas fa-users"></i> Donors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php"><i class="fas fa-hand-holding-usd"></i> Donations</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-calendar-alt"></i> More
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="event.php">Event</a></li>
                        <li><a class="dropdown-item" href="volunteer.php">Volunteer</a></li>
                        <li><a class="dropdown-item" href="event_volunteers.php">Volunteer_event</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>


<!-- Main content -->
<div class="container">
    <h1>Manage Donations</h1>

    <!-- Add Donation Button -->
    <div class="text-end">
        <button class="btn btn-add btn-sm" data-bs-toggle="modal" data-bs-target="#addDonationModal">Add Donation</button>
    </div>

    <!-- Table of Donations -->
    <div class="table-container">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Donation ID</th>
                    <th>Donor ID</th>
                    <th>Amount</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($donation = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$donation['donation_id']}</td>
                            <td>{$donation['donor_id']}</td>
                            <td>{$donation['donation_amount']}</td>
                            <td>{$donation['donation_type']}</td>
                            <td>{$donation['donation_date']}</td>
                            <td>
                                <button class='btn btn-edit btn-sm' data-bs-toggle='modal' data-bs-target='#editDonationModal'
                                    data-id='{$donation['donation_id']}'
                                    data-donorid='{$donation['donor_id']}'
                                    data-amount='{$donation['donation_amount']}'
                                    data-type='{$donation['donation_type']}'
                                    data-date='{$donation['donation_date']}' 
                                    data-bs-dismiss='modal'>
                                    <i class='fas fa-edit'></i> Edit
                                </button>  
                                <a href='delete_donation.php?donation_id={$donation['donation_id']}' class='btn btn-delete btn-sm' onclick='return confirm(\"Are you sure you want to delete this donation?\");'><i class='fas fa-trash'></i> Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No donations found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Donation Modal -->
<div class="modal fade" id="addDonationModal" tabindex="-1" aria-labelledby="addDonationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add_donation.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDonationModalLabel">Add Donation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="donor_id" class="form-label">Donor ID</label>
                        <input type="text" class="form-control" id="donor_id" name="donor_id" required>
                    </div>
                    <div class="mb-3">
                        <label for="donation_amount" class="form-label">Amount</label>
                        <input type="number" class="form-control" id="donation_amount" name="donation_amount" required>
                    </div>
                    <div class="mb-3">
                        <label for="donation_type" class="form-label">Type</label>
                        <select class="form-select" id="donation_type" name="donation_type" required>
                            <option value="recurring">Recurring</option>
                            <option value="one-time">One-time</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="donation_date" name="donation_date" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Donation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Donation Modal -->
<div class="modal fade" id="editDonationModal" tabindex="-1" aria-labelledby="editDonationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="edit_donation.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDonationModalLabel">Edit Donation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit_donation_id" name="donation_id">
                    <div class="mb-3">
                        <label for="edit_donor_id" class="form-label">Donor ID</label>
                        <input type="text" class="form-control" id="edit_donor_id" name="donor_id" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_donation_amount" class="form-label">Amount</label>
                        <input type="number" class="form-control" id="edit_donation_amount" name="donation_amount" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_donation_type" class="form-label">Type</label>
                        <select class="form-select" id="edit_donation_type" name="donation_type" required>
                            <option value="recurring">Recurring</option>
                            <option value="one-time">One-time</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="edit_donation_date" name="donation_date" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>
    <div class="container">
        <p>&copy; 2024 Charity Donation Management. All Rights Reserved.</p>
        <div class="footer-links">
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="privacy.php">Privacy Policy</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // When edit button is clicked, populate the modal with the donation data
    var editModal = document.getElementById('editDonationModal');
    editModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // Button that triggered the modal
        var donationId = button.getAttribute('data-id');
        var donorId = button.getAttribute('data-donorid');
        var amount = button.getAttribute('data-amount');
        var type = button.getAttribute('data-type');
        var date = button.getAttribute('data-date');

        // Populate the modal fields
        var modalDonationId = editModal.querySelector('#edit_donation_id');
        var modalDonorId = editModal.querySelector('#edit_donor_id');
        var modalAmount = editModal.querySelector('#edit_donation_amount');
        var modalType = editModal.querySelector('#edit_donation_type');
        var modalDate = editModal.querySelector('#edit_donation_date');

        modalDonationId.value = donationId;
        modalDonorId.value = donorId;
        modalAmount.value = amount;
        modalType.value = type;
        modalDate.value = date;
    });
</script>
</body>
</html>
