<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_id = $_POST['event_id'];
    $volunteer_id = $_POST['volunteer_id'];

    // Get volunteer name
    $volunteerQuery = "SELECT first_name, last_name FROM volunteers WHERE volunteer_id = $volunteer_id";
    $volunteerResult = mysqli_query($conn, $volunteerQuery);
    $volunteer = mysqli_fetch_assoc($volunteerResult);
    $volunteer_name = $volunteer['first_name'] . ' ' . $volunteer['last_name'];

    // Insert volunteer into event_volunteers
    $insertQuery = "INSERT INTO event_volunteers (event_id, event_name, volunteer_id, volunteer_name) 
                    VALUES ($event_id, (SELECT event_name FROM events WHERE event_id = $event_id), $volunteer_id, '$volunteer_name')";
    mysqli_query($conn, $insertQuery);

    header("Location: event_volunteers.php?event_id=$event_id");
}
?>
