<?php
session_start();
include 'db.php';  // Ensure this path is correct

// Check if donor_id is set in the session
if (isset($_SESSION['donor_id'])) {
    $donor_id = $_SESSION['donor_id'];
} else {
    // Redirect back to registration if donor_id is missing
    header("Location: register_donor.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donation_amount = $conn->real_escape_string($_POST['donation_amount']);
    $donation_type = $conn->real_escape_string($_POST['donation_type']);

    // Insert donation record
    $stmt = $conn->prepare("INSERT INTO donations (donor_id, donation_amount, donation_type) VALUES (?, ?, ?)");
    
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters and execute
    $stmt->bind_param("ids", $donor_id, $donation_amount, $donation_type);
    if ($stmt->execute()) {
        echo "<div class='alert alert-success' role='alert'>Donation registered successfully!</div>";
    } else {
        echo "<div class='alert alert-danger' role='alert'>Error: " . $stmt->error . "</div>";
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Donation</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #e3f2fd, #90caf9);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 100%;
        }
        button {
            padding: 15px;
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #138496;
        }
        .btn-back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #17a2b8;
        }
        .btn-back:hover {
            text-decoration: none;
            color: #138496;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Register Donation</h1>

        <form action="" method="POST">
            <div class="mb-3">
                <label for="donation_amount">Donation Amount (in USD):</label>
                <input type="number" step="0.01" id="donation_amount" name="donation_amount" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="donation_type">Donation Type:</label>
                <select id="donation_type" name="donation_type" class="form-select" required>
                    <option value="one-time">One-time</option>
                    <option value="recurring">Recurring</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-donate"></i> Register Donation
            </button>
        </form>

        <!-- Go Back to Home Button -->
        <a href="index_user.html" class="btn-back">
            <i class="fas fa-arrow-left"></i> Back to Home Page
        </a>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>
