<?php
// Include the database connection
include 'db.php';

if (isset($_GET['donation_id'])) {
    $donation_id = $_GET['donation_id'];

    // Delete the donation from the database
    $sql = "DELETE FROM donations WHERE donation_id = '$donation_id'";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the manage donations page with success message
        $_SESSION['message'] = 'Donation deleted successfully!';
        header("Location: donation.php");
    } else {
        // If error occurs, show the error
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
