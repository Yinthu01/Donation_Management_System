<?php
include 'db.php';

// Fetch volunteers
$volunteers_query = "SELECT * FROM volunteers";
$volunteers_result = mysqli_query($conn, $volunteers_query);

// Fetch events
$events_query = "SELECT * FROM events";
$events_result = mysqli_query($conn, $events_query);

// Fetch event_volunteers with details
$event_volunteers_query = "
    SELECT ev.*, v.first_name AS volunteer_first_name, v.last_name AS volunteer_last_name, e.event_name, e.description AS event_description, v.email AS volunteer_email
    FROM event_volunteers ev
    JOIN volunteers v ON ev.volunteer_id = v.volunteer_id
    JOIN events e ON ev.event_id = e.event_id
    ORDER BY ev.registration_date DESC
";
$event_volunteers_result = mysqli_query($conn, $event_volunteers_query);

// Error handling
if (!$volunteers_result || !$events_result || !$event_volunteers_result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>
