<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Individual Donors</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            overflow: hidden;
        }
        h1 {
            text-align: center;
            color: #fff;
            background: linear-gradient(90deg, #4caf50, #8bc34a);
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            animation: fadeIn 1s ease-in-out;
        }
        .stats-container {
            margin: 20px 0;
        }
        .card-deck .card {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeIn 1s ease-in-out;
        }
        .card-deck .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        .card-header {
            background: #4caf50;
            color: white;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
        .card-body {
            text-align: center;
            font-size: 22px;
        }
        .search-container {
            text-align: center;
            margin: 20px 0;
            animation: fadeIn 1s ease-in-out;
        }
        .search-container form {
            display: inline-block;
            text-align: left;
            transition: transform 0.3s ease;
        }
        .search-container form:hover {
            transform: translateY(-5px);
        }
        .search-container select, .search-container input {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .search-container select {
            background-color: #ffffff;
        }
        .search-container input[type="text"] {
            width: 250px;
        }
        .search-container input[type="submit"] {
            background-color: #4caf50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .search-container input[type="submit"]:hover {
            background-color: #45a049;
            transform: translateY(-3px);
        }
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
            animation: fadeIn 1s ease-in-out;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
            transition: background-color 0.3s ease;
        }
        th {
            background-color: #4caf50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
            transform: scale(1.02);
        }
        .no-data {
            text-align: center;
            padding: 20px;
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 5px;
            margin-top: 20px;
            animation: fadeIn 1s ease-in-out;
        }
        .count {
            font-size: 36px;
            font-weight: bold;
            color: #4caf50;
            animation: countUp 1s ease-in-out forwards;
        }
        @keyframes countUp {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Styles for the Go Back button */
        .go-back {
            display: block;
            margin: 30px auto;
            padding: 10px 20px;
            background-color: #4caf50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .go-back:hover {
            background-color: #45a049;
            transform: translateY(-3px);
        }

    </style>
</head>
<body>

<div class="container">
    <h1>List of Individual Donors</h1>

    <div class="stats-container">
        <div class="card-deck">
            <div class="card">
                <div class="card-header">This Week's Donors</div>
                <div class="card-body">
                    <div id="count-week" class="count">
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = ""; // Replace with your MySQL password
                        $dbname = "old1"; // Your database name

                        $conn = mysqli_connect($servername, $username, $password, $dbname);

                        if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                        }

                        $startOfWeek = date('Y-m-d', strtotime('monday this week'));

                        $sqlWeek = "SELECT COUNT(*) AS count FROM donors WHERE donor_type = 'individual' AND DATE(created_at) >= '$startOfWeek'";
                        $resultWeek = mysqli_query($conn, $sqlWeek);
                        $rowWeek = mysqli_fetch_assoc($resultWeek);
                        $countWeek = $rowWeek['count'];

                        echo $countWeek;

                        mysqli_close($conn);
                        ?>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">This Month's Donors</div>
                <div class="card-body">
                    <div id="count-month" class="count">
                        <?php
                        $conn = mysqli_connect($servername, $username, $password, $dbname);

                        $startOfMonth = date('Y-m-01');

                        $sqlMonth = "SELECT COUNT(*) AS count FROM donors WHERE donor_type = 'individual' AND DATE(created_at) >= '$startOfMonth'";
                        $resultMonth = mysqli_query($conn, $sqlMonth);
                        $rowMonth = mysqli_fetch_assoc($resultMonth);
                        $countMonth = $rowMonth['count'];

                        echo $countMonth;

                        mysqli_close($conn);
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="search-container">
            <form method="GET" action="">
                <select name="filter">
                    <option value="">Select Filter</option>
                    <option value="name" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'name' ? 'selected' : ''; ?>>Name</option>
                    <option value="email" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'email' ? 'selected' : ''; ?>>Email</option>
                    <option value="phone" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'phone' ? 'selected' : ''; ?>>Phone</option>
                    <option value="date" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'date' ? 'selected' : ''; ?>>Date</option>
                </select>
                <input type="text" name="search" placeholder="Search..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <input type="submit" value="Search">
            </form>
        </div>

        <?php
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        $filter = isset($_GET['filter']) ? mysqli_real_escape_string($conn, $_GET['filter']) : '';
        $searchQuery = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

        $sqlDonors = "SELECT first_name, last_name, email, phone, created_at FROM donors WHERE donor_type = 'individual'";

        if ($filter && $searchQuery) {
            if ($filter == 'name') {
                $sqlDonors .= " AND (first_name LIKE '%$searchQuery%' OR last_name LIKE '%$searchQuery%')";
            } elseif ($filter == 'email') {
                $sqlDonors .= " AND email LIKE '%$searchQuery%'";
            } elseif ($filter == 'phone') {
                $sqlDonors .= " AND phone LIKE '%$searchQuery%'";
            } elseif ($filter == 'date') {
                $sqlDonors .= " AND DATE(created_at) = '$searchQuery'";
            }
        }

        $resultDonors = mysqli_query($conn, $sqlDonors);
        ?>

        <table>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Registration Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($resultDonors) > 0) : ?>
                    <?php while ($row = mysqli_fetch_assoc($resultDonors)) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5" class="no-data">No donors found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php mysqli_close($conn); ?>
    </div>

    <!-- Go Back button at the bottom -->
    <button class="go-back" onclick="window.history.back()">Go Back to Previous Page</button>

</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>

</body>
</html>
