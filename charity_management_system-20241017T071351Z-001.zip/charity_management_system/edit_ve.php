<?php
include 'db.php';

if (isset($_GET['volunteer_id'])) {
    $volunteer_id = $_GET['volunteer_id'];

    // Fetch volunteer details
    $query = "SELECT * FROM volunteers WHERE volunteer_id = $volunteer_id";
    $result = mysqli_query($conn, $query);
    $volunteer = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $volunteer_id = $_POST['volunteer_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Update volunteer details
    $updateQuery = "UPDATE volunteers SET first_name='$first_name', last_name='$last_name', email='$email', phone='$phone' WHERE volunteer_id = $volunteer_id";
    mysqli_query($conn, $updateQuery);

    header("Location: event_volunteers.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Volunteer</title>
</head>
<body>

<form action="edit_volunteer.php" method="post">
    <input type="hidden" name="volunteer_id" value="<?= $volunteer['volunteer_id'] ?>">
    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" value="<?= $volunteer['first_name'] ?>" required><br>

    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" value="<?= $volunteer['last_name'] ?>" required><br>

    <label for="email">Email:</label>
    <input type="email" name="email" value="<?= $volunteer['email'] ?>" required><br>

    <label for="phone">Phone:</label>
    <input type="text" name="phone" value="<?= $volunteer['phone'] ?>" required><br>

    <input type="submit" value="Update Volunteer">
</form>

</body>
</html>
