<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recurring Donations</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #eaf4ff;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        h1 {
            text-align: center;
            color: #fff;
            background: linear-gradient(90deg, #0044cc, #3399ff);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            animation: fadeIn 1s ease-in-out;
        }
        .search-container {
            margin: 20px 0;
            display: flex;
            justify-content: center;
        }
        .search-container .card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-top: 5px solid #3399ff;
            max-width: 500px;
            width: 100%;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .search-container .card:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        .search-container .form-group {
            margin-bottom: 20px;
        }
        .search-container input {
            border: 1px solid #3399ff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s ease;
        }
        .search-container input:focus {
            border-color: #0044cc;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        }
        .search-container button {
            background-color: #0044cc;
            border: none;
            color: white;
            border-radius: 8px;
            padding: 12px 25px;
            margin-top: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .search-container button:hover {
            background-color: #0033aa;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .chart-container {
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }
        .chart-container .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            transition: transform 0.3s ease-in-out;
        }
        .chart-container .card:hover {
            transform: scale(1.02);
        }
        .chart-container .card-header {
            background-color: #0044cc;
            color: white;
            font-size: 1.4rem;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
            padding: 15px;
            transition: background-color 0.3s ease;
        }
        .chart-container .card-header:hover {
            background-color: #0033aa;
        }
        .chart-container .card-body {
            padding: 20px;
        }
        .chart-container canvas {
            border-radius: 8px;
            transition: box-shadow 0.3s ease;
        }
        .chart-container canvas:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        table {
            width: 100%;
            margin: 30px 0;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            transition: box-shadow 0.3s ease;
        }
        table:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        table, th, td {
            border: none;
        }
        th, td {
            padding: 12px;
            text-align: left;
            transition: background-color 0.3s ease;
        }
        th {
            background-color: #3399ff;
            color: #fff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f4f4f4;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
        .no-data {
            text-align: center;
            padding: 20px;
            background-color: #e9ecef;
            color: #6c757d;
            border-radius: 8px;
            margin-top: 30px;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .back-button {
            margin-top: 20px;
            text-align: center;
        }
        .back-button button {
            background-color: #0044cc;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-size: 1.1rem;
            font-weight: bold;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .back-button button:hover {
            background-color: #0033aa;
            color: #fff;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Recurring Donations</h1>

    <div class="search-container">
        <div class="card">
            <div class="card-body">
                <div class="card-header">
                    <i class="fas fa-search"></i> Search Donations
                </div>
                <form method="GET" action="">
                    <div class="form-group">
                        <label for="search">Search by Date:</label>
                        <input type="date" class="form-control" id="search" name="search_date" value="<?php echo isset($_GET['search_date']) ? htmlspecialchars($_GET['search_date']) : ''; ?>">
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>
            </div>
        </div>
    </div>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = ""; // Replace with your MySQL password
    $dbname = "old1"; // Your database name

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get search date if provided
    $search_date = isset($_GET['search_date']) ? mysqli_real_escape_string($conn, $_GET['search_date']) : '';

    // Query to fetch only recurring donations with donor details
    $sql = "SELECT d.donation_amount, d.donation_date, d.donation_type,
                   CONCAT(donors.first_name, ' ', donors.last_name) AS donor_name,
                   donors.organization_name, IFNULL(donors.donor_type, '-') AS donor_type
            FROM donations d
            JOIN donors ON d.donor_id = donors.donor_id
            WHERE d.donation_type = 'recurring'";

    if ($search_date) {
        $sql .= " AND DATE(d.donation_date) = '$search_date'";
    }

    $result = mysqli_query($conn, $sql);

    // Query to fetch recurring donation amounts over time
    $sql_chart = "SELECT DATE(donation_date) AS date, SUM(donation_amount) AS total_amount
                  FROM donations
                  WHERE donation_type = 'recurring'
                  GROUP BY DATE(donation_date)
                  ORDER BY DATE(donation_date)";

    $result_chart = mysqli_query($conn, $sql_chart);

    $dates = [];
    $amounts = [];

    while ($row_chart = mysqli_fetch_assoc($result_chart)) {
        $dates[] = $row_chart['date'];
        $amounts[] = $row_chart['total_amount'];
    }

    mysqli_close($conn);
    ?>

    <div class="chart-container">
        <div class="card">
            <div class="card-header">
                Donation Trends Over Time
            </div>
            <div class="card-body">
                <canvas id="donationChart"></canvas>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Organization</th>
                        <th>Donor Type</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['donor_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['organization_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['donor_type']); ?></td>
                            <td>$<?php echo number_format($row['donation_amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($row['donation_date']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No recurring donations found for the selected date.</div>
        <?php endif; ?>
    </div>

    <div class="back-button">
        <button onclick="window.history.back()"><i class="fas fa-arrow-left"></i> Back to Previous Page </button>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.8.0/chart.min.js"></script>
    <script>
        var ctx = document.getElementById('donationChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($dates); ?>,
                datasets: [{
                    label: 'Recurring Donations',
                    data: <?php echo json_encode($amounts); ?>,
                    backgroundColor: 'rgba(51, 153, 255, 0.4)', // Brighter blue shade
                    borderColor: '#0066ff', // Brighter blue shade
                    borderWidth: 2,
                    pointBackgroundColor: '#0066ff',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 8,
                    tension: 0.1,
                    fill: true,
                    cubicInterpolationMode: 'monotone'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return 'Amount: $' + tooltipItem.raw;
                            }
                        },
                        backgroundColor: '#333',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#666',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        },
                        ticks: {
                            autoSkip: true,
                            maxTicksLimit: 10
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Amount'
                        },
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
