<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>One-Time Donations</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        h1 {
            text-align: center;
            color: #fff;
            background: linear-gradient(90deg, #f36f6f, #f5a623);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .search-container {
            margin: 20px 0;
            display: flex;
            justify-content: center;
        }
        .search-container .card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-top: 5px solid #f36f6f;
            max-width: 500px;
            width: 100%;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .search-container .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .search-container .form-group {
            margin-bottom: 20px;
        }
        .search-container input {
            border: 1px solid #f36f6f;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .search-container input:focus {
            border-color: #d24d4d;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
            outline: none;
        }
        .search-container button {
            background-color: #f36f6f;
            border: none;
            color: white;
            border-radius: 8px;
            padding: 12px 25px;
            margin-top: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            font-weight: bold;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .search-container button:hover {
            background-color: #d24d4d;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .chart-container {
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }
        .chart-container .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .chart-container .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .chart-container .card-header {
            background-color: #f36f6f;
            color: white;
            font-size: 1.4rem;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
            padding: 15px;
        }
        .chart-container .card-body {
            padding: 20px;
        }
        .chart-container canvas {
            border-radius: 8px;
        }
        table {
            width: 100%;
            margin: 30px 0;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        table, th, td {
            border: none;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f5a623;
            color: #fff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e2e6ea;
        }
        .no-data {
            text-align: center;
            padding: 20px;
            background-color: #f8d7da;
            color: #721c24;
            border-radius: 8px;
            margin-top: 30px;
        }
        .go-back-btn {
            display: block;
            width: fit-content;
            margin: 20px auto;
            padding: 10px 20px;
            border: none;
            background: linear-gradient(90deg, #ffa500, #ff4500);
            color: white;
            border-radius: 8px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
        }
        .go-back-btn:hover {
            background: linear-gradient(90deg, #ff8c00, #ff6347);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<div class="container">
    <h1>One-Time Donations</h1>

    <div class="search-container">
        <div class="card">
            <div class="card-body">
                <div class="card-header">
                    <i class="fas fa-search"></i> Search Donations
                </div>
                <form method="GET" action="">
                    <div class="form-group">
                        <label for="search">Search by Date:</label>
                        <input type="date" class="form-control" id="search" name="search_date" value="<?php echo isset($_GET['search_date']) ? htmlspecialchars($_GET['search_date']) : ''; ?>">
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>
            </div>
        </div>
    </div>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = ""; // Replace with your MySQL password
    $dbname = "old1"; // Your database name

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get search date if provided
    $search_date = isset($_GET['search_date']) ? mysqli_real_escape_string($conn, $_GET['search_date']) : '';

    // Query to fetch only one-time donations with donor details
    $sql = "SELECT d.donation_amount, d.donation_date, d.donation_type,
                   CONCAT(donors.first_name, ' ', donors.last_name) AS donor_name,
                   donors.organization_name
            FROM donations d
            JOIN donors ON d.donor_id = donors.donor_id
            WHERE d.donation_type = 'one-time'";

    if ($search_date) {
        $sql .= " AND DATE(d.donation_date) = '$search_date'";
    }

    $result = mysqli_query($conn, $sql);

    // Query to fetch one-time donation amounts over time
    $sql_chart = "SELECT DATE(donation_date) AS date, SUM(donation_amount) AS total_amount
                  FROM donations
                  WHERE donation_type = 'one-time'";

    if ($search_date) {
        $sql_chart .= " AND DATE(donation_date) = '$search_date'";
    }

    $sql_chart .= " GROUP BY DATE(donation_date)
                    ORDER BY DATE(donation_date)";

    $result_chart = mysqli_query($conn, $sql_chart);

    $dates = [];
    $amounts = [];

    while ($row = mysqli_fetch_assoc($result_chart)) {
        $dates[] = $row['date'];
        $amounts[] = $row['total_amount'];
    }

    mysqli_close($conn);
    ?>

    <div class="chart-container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-chart-line"></i> Donation Trends
            </div>
            <div class="card-body">
                <canvas id="donationChart"></canvas>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (mysqli_num_rows($result) > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Organization</th>
                        <th>Donation Amount</th>
                        <th>Donation Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['donor_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['organization_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['donation_amount']); ?></td>
                            <td><?php echo htmlspecialchars($row['donation_date']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <div class="no-data">
                No data available for the selected date.
            </div>
        <?php } ?>
    </div>

    <a href="option.html" class="go-back-btn"><i class="fas fa-arrow-left"></i> Go Back to Previous Page </a>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script>
    var ctx = document.getElementById('donationChart').getContext('2d');
    var donationChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($dates); ?>,
            datasets: [{
                label: 'Donation Amount',
                data: <?php echo json_encode($amounts); ?>,
                borderColor: '#ff4500',
                backgroundColor: 'rgba(255, 69, 0, 0.2)',
                borderWidth: 2,
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>
