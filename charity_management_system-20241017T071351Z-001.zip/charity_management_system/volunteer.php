<?php
include 'db.php';

// Fetch all volunteers from the database
$query = "SELECT * FROM volunteers ORDER BY volunteer_id DESC";
$result = mysqli_query($conn, $query);

// Error handling
if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Navbar Styling */
.navbar {
    background-color: #343a40;
    padding: 1rem;
}

.navbar-brand {
    color: #fff;
    font-size: 1.5rem;
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #ddd;
    margin-left: 20px;
    position: relative;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
}

/* Hover effect for normal nav links */
.navbar-nav .nav-link:hover {
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    transition: 0.3s;
}

/* Dropdown specific styling */
.navbar-nav .dropdown-menu {
    background-color: #444;
    border: none;
    border-radius: 10px;
    padding: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    margin-top: 10px;
}

.navbar-nav .dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
}

/* Dropdown item styling */
.navbar-nav .dropdown-item {
    color: #ddd;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

/* Hover effect for dropdown items */
.navbar-nav .dropdown-item:hover {
    background-color: #ff7f50;
    color: white;
    transform: scale(1.05);
}

/* Arrow styling for the dropdown toggle */
.navbar-nav .dropdown-toggle::after {
    display: none;
}

.navbar-nav .dropdown-toggle:after {
    content: '\25BC'; /* Unicode for a down arrow */
    margin-left: 5px;
    font-size: 0.8rem;
    color: #ddd;
    transition: transform 0.3s ease;
}

/* Rotate arrow when dropdown is open */
.navbar-nav .dropdown-toggle[aria-expanded="true"]::after {
    transform: rotate(180deg);
}

        .volunteer-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .volunteer-header h2 {
            font-size: 1.8rem;
            font-weight: bold;
        }
        .volunteer-table th, .volunteer-table td {
            text-align: center;
        }
        .modal-header {
            background-color: #343a40;
            color: white;
        }
        .btn-add-volunteer {
            background-color: #28a745;
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            color: white;
        }
        .btn-edit, .btn-delete {
            padding: 5px 10px;
            color: white;
        }
        .btn-edit {
            background-color: #ffc107;
        }
        .btn-delete {
            background-color: #dc3545;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-hands-helping"></i> Charity Management</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_donors.php"><i class="fas fa-users"></i> Donors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php"><i class="fas fa-hand-holding-usd"></i> Donations</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-calendar-alt"></i> More
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="event.php">Event</a></li>
                        <li><a class="dropdown-item" href="volunteer.php">Volunteer</a></li>
                        <li><a class="dropdown-item" href="event_volunteers.php">Volunteer_event</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main container -->
<div class="container mt-5">
    <div class="volunteer-header">
        <h2>Manage Volunteers</h2>
        <button class="btn btn-add-volunteer" data-bs-toggle="modal" data-bs-target="#addVolunteerModal">
            <i class="fas fa-plus"></i> Add Volunteer
        </button>
    </div>

    <!-- Display message if set -->
    <?php if (isset($_GET['message'])): ?>
        <div class="alert alert-success" role="alert">
            <?php echo htmlspecialchars($_GET['message']); ?>
        </div>
    <?php endif; ?>

    <!-- Volunteer Table -->
    <table class="table table-bordered table-striped volunteer-table">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0):
                while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($row['volunteer_id']); ?></td>
                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                <td>
                    <button class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#editVolunteerModal" 
                        data-id="<?php echo htmlspecialchars($row['volunteer_id']); ?>"
                        data-firstname="<?php echo htmlspecialchars($row['first_name']); ?>"
                        data-lastname="<?php echo htmlspecialchars($row['last_name']); ?>"
                        data-email="<?php echo htmlspecialchars($row['email']); ?>"
                        data-phone="<?php echo htmlspecialchars($row['phone']); ?>">
                        <i class="fas fa-edit"></i>
                    </button>
                    <a href="delete_volunteer.php?id=<?php echo htmlspecialchars($row['volunteer_id']); ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this volunteer?');">
                        <i class="fas fa-trash-alt"></i>
                    </a>
                </td>
            </tr>
            <?php
                endwhile;
            else:
            ?>
            <tr>
                <td colspan="6">No volunteers found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Add Volunteer Modal -->
<div class="modal fade" id="addVolunteerModal" tabindex="-1" aria-labelledby="addVolunteerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addVolunteerModalLabel">Add Volunteer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="insert_volunteer.php" method="POST">
                    <div class="mb-3">
                        <label for="first_name" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add Volunteer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Volunteer Modal -->
<div class="modal fade" id="editVolunteerModal" tabindex="-1" aria-labelledby="editVolunteerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editVolunteerModalLabel">Edit Volunteer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="edit_volunteer.php" method="POST">
                    <input type="hidden" id="edit_volunteer_id" name="volunteer_id">
                    <div class="mb-3">
                        <label for="edit_first_name" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="edit_first_name" name="first_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_last_name" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="edit_last_name" name="last_name">
                    </div>
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="edit_phone" name="phone">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Update Volunteer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', function() {
        let volunteerId = this.getAttribute('data-id');
        let firstName = this.getAttribute('data-firstname');
        let lastName = this.getAttribute('data-lastname');
        let email = this.getAttribute('data-email');
        let phone = this.getAttribute('data-phone');

        document.getElementById('edit_volunteer_id').value = volunteerId;
        document.getElementById('edit_first_name').value = firstName;
        document.getElementById('edit_last_name').value = lastName;
        document.getElementById('edit_email').value = email;
        document.getElementById('edit_phone').value = phone;
    });
});
</script>

</body>
</html>
