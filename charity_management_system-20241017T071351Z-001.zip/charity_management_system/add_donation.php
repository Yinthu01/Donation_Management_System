<?php
// Include the database connection
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form input values
    $donation_amount = $_POST['donation_amount'] ?? '';
    $donation_type = $_POST['donation_type'] ?? '';
    $donor_id = $_POST['donor_id'] ?? '';
    $donation_date = $_POST['donation_date'] ?? '';  // Capture the donation date
    
    // Validate donation type
    $valid_types = ['one-time', 'recurring'];
    if (!in_array($donation_type, $valid_types)) {
        echo "<script>
                alert('Invalid donation type.');
                window.location.href = 'donation.php';
              </script>";
        exit();
    }
    
    // Check if donor_id exists in the donors table
    $stmt = $conn->prepare("SELECT * FROM donors WHERE donor_id = ?");
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $donorResult = $stmt->get_result();

    if ($donorResult->num_rows > 0) {
        // If donor exists, proceed to insert the donation
        $stmt = $conn->prepare("INSERT INTO donations (donation_amount, donation_type, donor_id, donation_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("dsis", $donation_amount, $donation_type, $donor_id, $donation_date);

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Donation added successfully!';
            header('Location: donation.php');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "<script>
                alert('Donor ID does not exist. Please provide a valid donor.');
                window.location.href = 'donation.php';
              </script>";
        exit();
    }
}
?>


