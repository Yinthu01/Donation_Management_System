<?php
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_name = mysqli_real_escape_string($conn, $_POST['event_name']);
    $event_description = mysqli_real_escape_string($conn, $_POST['event_description']);
    $event_date = mysqli_real_escape_string($conn, $_POST['event_date']);
    $event_time = mysqli_real_escape_string($conn, $_POST['event_time']);
    $event_location = mysqli_real_escape_string($conn, $_POST['event_location']);

    // Insert event into the database
    $query = "INSERT INTO events (event_name, event_date, location, description, event_time) 
              VALUES ('$event_name', '$event_date', '$event_location', '$event_description', '$event_time')";

    if (mysqli_query($conn, $query)) {
        header("Location: event.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
