<?php
// Initialize an empty message variable
$message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "old1";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO volunteers (first_name, last_name, email, phone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $first_name, $last_name, $email, $phone);

    // Get form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Execute the statement
    if ($stmt->execute()) {
        $message = "Volunteer registered successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #6dd5ed, #2193b0); /* Gradient background */
            font-family: Arial, sans-serif;
        }
        .form-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 50px;
            transition: transform 0.3s;
        }
        .form-container:hover {
            transform: scale(1.02);
        }
        .form-label {
            font-weight: bold;
            transition: color 0.3s;
        }
        .form-control {
            border-radius: 10px;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .form-control:hover, .form-control:focus {
            background-color: #e9ecef;
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
        }
        .btn-custom {
            background-color: #007bff;
            border-color: #007bff;
            color: white;
            font-weight: bold;
            transition: background-color 0.3s, box-shadow 0.3s;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            border-color: #004085;
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
        }
        .btn-custom:active {
            background-color: #003f7f;
        }
        .icon-field {
            position: relative;
        }
        .icon-field i {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #007bff;
            transition: color 0.3s;
        }
        .form-control:hover + i, .form-control:focus + i {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="form-container">
                    <h2 class="text-center mb-4"><i class="fas fa-user-plus"></i> Volunteer Registration</h2>
                    <!-- Show feedback message -->
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-info" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <!-- First Name -->
                        <div class="mb-3 form-group icon-field">
                            <label for="first_name" class="form-label"><i class="fas fa-signature"></i> First Name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name" required>
                        </div>
                        <!-- Last Name -->
                        <div class="mb-3 form-group icon-field">
                            <label for="last_name" class="form-label"><i class="fas fa-signature"></i> Last Name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter last name">
                        </div>
                        <!-- Email -->
                        <div class="mb-3 form-group icon-field">
                            <label for="email" class="form-label"><i class="fas fa-envelope"></i> Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
                        </div>
                        <!-- Phone -->
                        <div class="mb-3 form-group icon-field">
                            <label for="phone" class="form-label"><i class="fas fa-phone"></i> Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone number">
                        </div>
                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-custom w-100">
                            <i class="fas fa-paper-plane"></i> Register
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Go Back to Home Button -->
    <div class="container text-center mt-4">
        <a href="index_user.html" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Home Page
        </a>
    </div>
</body>
</html>
