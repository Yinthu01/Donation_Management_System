<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "old1";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind (without event_time)
    $stmt = $conn->prepare("INSERT INTO events (event_name, event_date, location, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $event_name, $event_date, $location, $description);

    // Set parameters and execute
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $location = $_POST['event_location'];
    $description = $_POST['event_description'];

    if ($stmt->execute()) {
        $message = "New event registered successfully";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #9FE2BF;
        }
        .form-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        .form-label {
            font-weight: bold;
        }
        .btn-custom {
            background-color: #28a745;
            border-color: #28a745;
            color: white;
            transition: all 0.3s ease-in-out;
        }
        .btn-custom:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="form-container">
                    <h2 class="text-center mb-4"><i class="fas fa-calendar-plus"></i> Event Registration</h2>
                    <?php
                    if (isset($message)) {
                        echo '<div class="alert alert-info" role="alert">' . htmlspecialchars($message) . '</div>';
                    }
                    ?>
                    <form action="" method="POST">
                        <!-- Event Name -->
                        <div class="mb-3">
                            <label for="event_name" class="form-label"><i class="fas fa-signature"></i> Event Name</label>
                            <input type="text" class="form-control" id="event_name" name="event_name" placeholder="Enter event name" required>
                        </div>
                        <!-- Event Date -->
                        <div class="mb-3">
                            <label for="event_date" class="form-label"><i class="fas fa-calendar-alt"></i> Event Date</label>
                            <input type="date" class="form-control" id="event_date" name="event_date" required>
                        </div>
                        <!-- Event Location -->
                        <div class="mb-3">
                            <label for="event_location" class="form-label"><i class="fas fa-map-marker-alt"></i> Event Location</label>
                            <input type="text" class="form-control" id="event_location" name="event_location" placeholder="Enter event location" required>
                        </div>
                        <!-- Event Description -->
                        <div class="mb-3">
                            <label for="event_description" class="form-label"><i class="fas fa-align-left"></i> Event Description</label>
                            <textarea class="form-control" id="event_description" name="event_description" rows="4" placeholder="Enter a brief description of the event" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-custom w-100"><i class="fas fa-paper-plane"></i> Register</button>
                    </form>
                    <!-- Go Back to Home Button -->
                    <a href="index_user.html" class="btn btn-back w-100">
                        <i class="fas fa-arrow-left"></i> Back to Home Page
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
