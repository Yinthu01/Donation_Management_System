<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $volunteer_id = $_POST['volunteer_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "UPDATE volunteers SET first_name='$first_name', last_name='$last_name', email='$email', phone='$phone' WHERE volunteer_id=$volunteer_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        header("Location: volunteer.php");
    } else {
        die("Update query failed: " . mysqli_error($conn));
    }
}
?>
