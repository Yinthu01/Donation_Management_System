-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2024 at 11:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `old1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', 'admin123', '2024-09-12 14:44:01');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `donation_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `donation_amount` decimal(10,2) NOT NULL,
  `donation_type` enum('one-time','recurring') NOT NULL,
  `donation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`donation_id`, `donor_id`, `donation_amount`, `donation_type`, `donation_date`) VALUES
(3, 2, 500.00, 'one-time', '2024-09-16 16:00:00'),
(5, 3, 3000.00, 'recurring', '2024-09-13 03:29:43'),
(6, 8, 700.00, 'one-time', '2024-09-09 04:31:12'),
(9, 15, 100.00, 'one-time', '2024-09-14 02:35:50'),
(11, 17, 2000.00, 'one-time', '2024-09-14 04:28:32'),
(12, 18, 13.00, 'one-time', '2024-09-14 05:13:37'),
(13, 20, 450.00, 'one-time', '2024-09-14 08:03:44'),
(15, 5, 4500.00, 'one-time', '2024-09-26 16:00:00'),
(16, 3, 2000.00, 'recurring', '2024-09-19 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `donor_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `donor_type` enum('individual','organization') NOT NULL DEFAULT 'individual',
  `organization_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`donor_id`, `first_name`, `last_name`, `email`, `phone`, `donor_type`, `organization_name`, `created_at`) VALUES
(1, 'salina', 'gomeous', 'salina@gmail.com', '01446698875633', 'individual', NULL, '2024-09-26 21:14:19'),
(2, '', NULL, 'contact@facebook.com', '111-222-3333', 'organization', 'Facebook', '2024-09-12 14:44:01'),
(3, 'su', 'lus', 'su@gmail.com', '3457898765433', 'individual', NULL, '2024-09-12 17:08:25'),
(5, 'lu', 'tu', 'lu@gmail.com', '4567788888', 'individual', NULL, '2024-09-12 17:36:23'),
(8, 'zu', 'ha', 'ha@gmail.com', '3456676574', 'individual', NULL, '2024-09-09 04:29:21'),
(11, 'ha', 'na', 'ha@gmail.com', '1234578990', 'individual', '', '2024-09-13 19:10:55'),
(14, 'Zin May ', 'Oo', 'zin@gmail.com', '0124578963', 'individual', NULL, '2024-09-14 00:01:46'),
(15, 'nai', 'nai', 'nai@gmail.com', '0324579654', 'individual', NULL, '2024-09-14 02:35:39'),
(17, 'Johny', 'Paul', 'hasiba@gmail.com', '012459635', 'individual', NULL, '2024-09-14 04:28:21'),
(18, 'Salina', 'Swifty', 'penguin01bear@gmail.com', '345211111112', 'individual', NULL, '2024-09-14 05:13:22'),
(19, 'su', 'la', 'su@gmail.com', '578765131', 'individual', NULL, '2024-09-14 05:23:19'),
(20, 'Mohamed', 'Imadh', 'imadh@gmail.com', '2147512335', 'individual', NULL, '2024-09-14 08:02:51'),
(22, 'Mohmoodha', 'Imadh', 'mohmoodha@gmail.com', '014578', 'individual', 'Taylor ', '2024-09-14 08:23:39'),
(23, 'viky', 'tun', 'viky@gmail', '014789566', 'individual', NULL, '2024-09-14 08:50:29'),
(24, 'viky', 'tun', 'viky@gmail.com', '01478952332', 'individual', NULL, '2024-09-14 08:52:59');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_time` time NOT NULL DEFAULT '00:00:00',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `event_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_date`, `location`, `description`, `event_time`, `created_at`, `event_description`) VALUES
(4, 'Hospital Cleaning', '2024-09-17', 'Government Hospital', '', '19:00:00', '2024-09-13 08:45:24', NULL),
(5, 'Concert', '2024-09-16', 'Kuala Lumpur', 'singing', '15:47:00', '2024-09-13 19:45:48', NULL),
(6, 'Hospital Cleaning', '2024-09-17', '', NULL, '00:00:00', '2024-09-13 22:05:29', NULL),
(7, 'Hospital Cleaning', '2024-09-20', '', NULL, '00:00:00', '2024-09-13 22:05:47', NULL),
(8, 'Hospital Cleaning', '2024-09-14', 'Kedah', 'Hosipital Cleaning at kedah for National Day', '00:00:00', '2024-09-13 22:47:49', NULL),
(9, 'Concert', '2024-09-19', 'Kuala Lumpur', 'concert ar kuala lumpur', '00:00:00', '2024-09-13 22:48:19', NULL),
(11, 'Concert', '2024-09-19', 'Kuala Lumpur', 'concert ar kuala lumpur', '00:00:00', '2024-09-13 22:54:00', NULL),
(12, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 22:56:30', NULL),
(13, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 22:58:50', NULL),
(14, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 22:59:24', NULL),
(15, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 23:01:37', NULL),
(16, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 23:02:27', NULL),
(17, 'blood donation ', '2024-09-01', 'seoul korea', 'need volunteer for our blood donation camp that\'s happening in seoul korea', '00:00:00', '2024-09-13 23:44:27', NULL),
(18, 'Blood Donation', '2024-09-20', 'Government Hospital', 'Blood Donaiton at Government Hospital by Hasiba', '00:00:00', '2024-09-14 00:03:46', NULL),
(19, 'Hospital Cleaning', '2024-09-17', 'Alor ', 'Setor', '00:00:00', '2024-09-14 02:43:17', NULL),
(20, 'Blood Donation', '2024-09-18', 'Alor ', 'Setor', '00:00:00', '2024-09-14 02:43:36', NULL),
(21, 'Kyle concert', '2024-09-10', 'Alor setar', 'Organized by Kyle corporation', '00:00:00', '2024-09-14 08:05:32', NULL),
(22, 'blood donation', '2024-09-24', 'Jitra', 'organized oublic hospital', '00:00:00', '2024-09-14 08:17:45', NULL),
(23, 'blood donation ', '2024-09-26', 'KL', 'Blood donation at KL', '08:30:00', '2024-09-14 08:26:01', NULL),
(24, 'blood donation ', '2024-09-20', 'Alor setar', 'blood donation at Alor Setor', '21:00:00', '2024-09-14 08:55:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `event_volunteers`
--

CREATE TABLE `event_volunteers` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `volunteer_name` varchar(255) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_volunteers`
--

INSERT INTO `event_volunteers` (`event_id`, `event_name`, `volunteer_id`, `volunteer_name`, `registration_date`) VALUES
(4, '', 2, '', '2024-09-13 16:00:00'),
(4, '', 3, '', '2024-09-13 16:00:00'),
(4, '', 5, '', '2024-09-13 16:00:00'),
(4, '', 6, '', '2024-09-11 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `volunteer_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`volunteer_id`, `first_name`, `last_name`, `email`, `phone`, `created_at`) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '123-456-7890', '2024-09-13 04:55:45'),
(2, 'Alice', 'Smith', 'alice.smith@example.com', '123-456-7890', '2024-09-13 05:07:03'),
(3, 'Bob', 'Johnson', 'bob.johnson@example.com', '234-567-8901', '2024-09-13 05:07:03'),
(4, 'Charlie', 'Williams', 'charlie.williams@example.com', '345-678-9012', '2024-09-13 05:07:03'),
(5, 'Johny', 'Deep', 'johny@gmail.com', '12334789900', '2024-09-13 08:51:15'),
(6, 'Salina', 'Gomeous', 'salina@gmail.com', '1237889090000', '2024-09-13 08:54:46'),
(8, 'Taylor', 'Mop', 'taylor@gmail.com', '5548996588', '2024-09-13 09:06:07'),
(9, 'Peter', 'Paul', 'peter@gmail.com', '0145879965', '2024-09-13 09:11:53'),
(12, 'Taehyung', 'Hasiba', 'mrsv@gmail.com', '1234567891011', '2024-09-13 23:12:03'),
(13, 'Hasiba', 'NO', 'hasiba@gmail.com', '01256983589', '2024-09-14 00:04:26'),
(14, 'zuha', 'manal', 'zu@gmail.com', '0339653485764', '2024-09-14 00:06:41'),
(15, 'Salina', 'Deep', 'taylor@gmail.com', '03255899988', '2024-09-14 00:07:26'),
(16, 'alseo', 'Swift', 'swift@gmail.com', '025749863', '2024-09-14 00:09:36'),
(17, 'Salina', 'Swift', 'salina@gmail.com', '12334789900', '2024-09-14 02:53:10'),
(18, 'Salina', 'Swift', 'salina@gmail.com', '12334789900', '2024-09-14 03:19:58'),
(19, 'smeet', 'tun', 'smeet@gmail.com', '0234578952', '2024-09-14 03:20:30'),
(20, 'alseo', 'Gomeous', 'salina@gmail.com', '345211111112', '2024-09-14 03:25:44'),
(21, 'alseo', 'Gomeous', 'salina@gmail.com', '345211111112', '2024-09-14 03:27:16'),
(22, 'Johny', 'Deep', 'jony@gmail.com', '025479631', '2024-09-14 03:28:10'),
(23, 'Johny', 'Mop', 'jony@gmail.com', '025479631', '2024-09-14 03:29:51'),
(24, 'mahmoo', 'dha', 'mahmoo@gmail.com', '0974586321', '2024-09-14 03:30:19'),
(25, 'hisra', 'hisham', 'hisra@gmail.com', '1', '2024-09-14 08:18:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donation_id`),
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`donor_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `event_volunteers`
--
ALTER TABLE `event_volunteers`
  ADD PRIMARY KEY (`event_id`,`volunteer_id`),
  ADD KEY `fk_volunteer_id` (`volunteer_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`volunteer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `donation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `donor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `volunteer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`donor_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_volunteers`
--
ALTER TABLE `event_volunteers`
  ADD CONSTRAINT `fk_event_id` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_volunteer_id` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteers` (`volunteer_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
