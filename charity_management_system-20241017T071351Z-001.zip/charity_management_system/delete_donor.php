<?php
include 'db.php';

if (isset($_GET['donor_id'])) {
    $donor_id = mysqli_real_escape_string($conn, $_GET['donor_id']);

    // Delete the donor from the database
    $query = "DELETE FROM donors WHERE donor_id = '$donor_id'";

    if (mysqli_query($conn, $query)) {
        // Redirect to manage_donors.php after deletion
        header("Location: manage_donors.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
} else {
    // Redirect if donor_id is not set
    header("Location: manage_donors.php");
    exit();
}
?>
