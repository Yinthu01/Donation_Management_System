<?php
// Include the database connection
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donation_id = $_POST['donation_id'];
    $donor_id = $_POST['donor_id'];
    $donation_amount = $_POST['donation_amount'];
    $donation_type = $_POST['donation_type'];
    $donation_date = $_POST['donation_date'];  // Capture donation date from the form

    // Update the donation in the database
    $sql = "UPDATE donations 
            SET donor_id = '$donor_id', donation_amount = '$donation_amount', donation_type = '$donation_type', donation_date = '$donation_date'
            WHERE donation_id = '$donation_id'";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the manage donations page with success message
        $_SESSION['message'] = 'Donation updated successfully!';
        header("Location: donation.php");
    } else {
        // If error occurs, show the error
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
