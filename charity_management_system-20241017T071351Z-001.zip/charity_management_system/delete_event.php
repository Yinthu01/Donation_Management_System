<?php
include 'db.php';

if (isset($_GET['id'])) {
    $event_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Delete event from the database
    $query = "DELETE FROM events WHERE event_id = '$event_id'";

    if (mysqli_query($conn, $query)) {
        header("Location: event.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
