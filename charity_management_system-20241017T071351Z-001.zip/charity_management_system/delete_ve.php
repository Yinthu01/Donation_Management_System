<?php
include 'db.php';

if (isset($_GET['volunteer_id']) && isset($_GET['event_id'])) {
    $volunteer_id = $_GET['volunteer_id'];
    $event_id = $_GET['event_id'];

    // Delete volunteer from event_volunteers
    $deleteQuery = "DELETE FROM event_volunteers WHERE volunteer_id = $volunteer_id AND event_id = $event_id";
    mysqli_query($conn, $deleteQuery);

    header("Location: event_volunteers.php?event_id=$event_id");
}
?>
