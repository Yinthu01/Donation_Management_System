<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #fbc2eb, #a6c0fe); /* Gradient background */
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #e74c3c; /* Red color for headings */
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .stats {
            display: flex;
            justify-content: space-between;
            background: #d36c6c; /* Darker pink background for stats box */
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            animation: slideIn 1s ease-out;
        }
        @keyframes slideIn {
            from { transform: translateX(-100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .stats > div {
            flex: 1;
            margin: 0 10px;
            padding: 20px;
            text-align: center;
            background: #e57373; /* Slightly lighter dark pink background for each box */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: background 0.3s, transform 0.3s;
        }
        .stats > div:hover {
            background: #f06292; /* Lighter pink on hover */
            transform: scale(1.05);
        }
        .stats h2 {
            color: #fff; /* White color for text in stats boxes */
            font-size: 1.4rem; /* Smaller font size */
            margin: 0;
            transition: color 0.3s;
        }
        .stats > div:hover h2 {
            color: #fff;
        }
        .event {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            animation: fadeIn 1s ease-out;
        }
        .event:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            animation: pulse 1s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }
        .event h2 {
            color: #e74c3c; /* Red color for event names */
            margin-top: 0;
            font-size: 1.6rem;
            transition: color 0.3s;
        }
        .event:hover h2 {
            color: #d36c6c; /* Darker pink on hover */
        }
        .event p {
            margin: 10px 0;
            font-size: 0.9rem; /* Smaller font size */
            color: #555;
        }
        .events {
            border-top: 4px solid #e74c3c; /* Red border on top */
            margin-top: 20px;
            padding-top: 20px;
        }
        .events h3 {
            color: #e74c3c; /* Red color for events heading */
            font-size: 1.4rem;
        }
        .events ul {
            list-style-type: none;
            padding: 0;
        }
        .events li {
            background: #fff;
            border-radius: 8px;
            margin: 10px 0;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, transform 0.3s;
            animation: fadeIn 1s ease-out;
        }
        .events li:hover {
            background-color: #f7f7f7;
            transform: scale(1.02);
        }
        .no-data {
            text-align: center;
            font-style: italic;
            color: #666;
            font-size: 1.2rem;
        }
        .search-form {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-form input[type="text"] {
            padding: 10px;
            width: 80%;
            max-width: 400px;
            border: 2px solid #d36c6c; /* Dark pink border */
            border-radius: 5px;
            font-size: 1rem;
            margin-right: 10px;
            transition: border-color 0.3s;
        }
        .search-form input[type="text"]:focus {
            border-color: #c6286c; /* Slightly darker pink on focus */
            outline: none;
        }
        .search-form input[type="submit"] {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #d36c6c; /* Dark pink background */
            color: #fff;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }
        .search-form input[type="submit"]:hover {
            background-color: #c6286c; /* Slightly darker pink on hover */
            transform: scale(1.05);
        }
        .back-button {
            display: block;
            margin: 20px auto;
            width: fit-content;
            padding: 10px 20px;
            text-align: center;
            border: none;
            border-radius: 5px;
            background-color: #d36c6c; /* Dark pink background */
            color: #fff;
            font-size: 1rem;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s;
        }
        .back-button:hover {
            background-color: #c6286c; /* Slightly darker pink on hover */
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Event Details</h1>

    <!-- Search Form -->
    <div class="search-form">
        <form method="get" action="">
            <input type="text" name="search" placeholder="Search events by name or description..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <input type="submit" value="Search">
        </form>
    </div>

    <?php
    // Database connection
    require_once 'db.php';

    // Get search query
    $search_query = isset($_GET['search']) ? $_GET['search'] : '';

    // Fetch total number of events
    $total_events_sql = "SELECT COUNT(*) as total FROM events WHERE event_name LIKE ? OR description LIKE ?";
    $stmt = $conn->prepare($total_events_sql);
    $search_term = '%' . $search_query . '%';
    $stmt->bind_param('ss', $search_term, $search_term);
    $stmt->execute();
    $total_events_result = $stmt->get_result();
    $total_events = $total_events_result->fetch_assoc()['total'];

    // Fetch number of upcoming events
    $upcoming_events_sql = "SELECT COUNT(*) as upcoming FROM events WHERE event_date > NOW() AND (event_name LIKE ? OR description LIKE ?)";
    $stmt = $conn->prepare($upcoming_events_sql);
    $stmt->bind_param('ss', $search_term, $search_term);
    $stmt->execute();
    $upcoming_events_result = $stmt->get_result();
    $upcoming_events = $upcoming_events_result->fetch_assoc()['upcoming'];

    // Fetch number of past events
    $past_events_sql = "SELECT COUNT(*) as past FROM events WHERE event_date <= NOW() AND (event_name LIKE ? OR description LIKE ?)";
    $stmt = $conn->prepare($past_events_sql);
    $stmt->bind_param('ss', $search_term, $search_term);
    $stmt->execute();
    $past_events_result = $stmt->get_result();
    $past_events = $past_events_result->fetch_assoc()['past'];

    // Display event statistics
    echo "<div class='stats'>";
    echo "<div><h2>Total Events: " . $total_events . "</h2></div>";
    echo "<div><h2>Upcoming Events: " . $upcoming_events . "</h2></div>";
    echo "<div><h2>Past Events: " . $past_events . "</h2></div>";
    echo "</div>";

    // Fetch all events based on search query
    $sql = "SELECT * FROM events WHERE event_name LIKE ? OR description LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $event_id = $row['event_id'];
            $event_name = $row['event_name'];
            $event_date = $row['event_date'];
            $event_time = $row['event_time'];
            $location = $row['location'];
            $description = $row['description'];

            // Display event details
            echo "<div class='event'>";
            echo "<h2>Event: " . htmlspecialchars($event_name) . "</h2>";
            echo "<p>Date: " . htmlspecialchars($event_date) . "</p>";
            echo "<p>Time: " . htmlspecialchars($event_time) . "</p>";
            echo "<p>Location: " . htmlspecialchars($location) . "</p>";
            echo "<p>Description: " . htmlspecialchars($description) . "</p>";

            // Fetch volunteers for the current event
            $volunteer_sql = "
                SELECT v.first_name, v.last_name, v.email, v.phone
                FROM event_volunteers ev
                INNER JOIN volunteers v ON ev.volunteer_id = v.volunteer_id
                WHERE ev.event_id = ?
            ";
            $stmt = $conn->prepare($volunteer_sql);
            $stmt->bind_param("i", $event_id);
            $stmt->execute();
            $volunteer_result = $stmt->get_result();

            // Display volunteers
            if ($volunteer_result->num_rows > 0) {
                echo "<div class='events'>";
                echo "<h3>Volunteers:</h3>";
                echo "<ul>";
                while ($volunteer = $volunteer_result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($volunteer['first_name']) . " " . htmlspecialchars($volunteer['last_name']) . 
                    " - Email: " . htmlspecialchars($volunteer['email']) . 
                    " - Phone: " . htmlspecialchars($volunteer['phone']) . "</li>";
                }
                echo "</ul>";
                echo "</div>";
            } else {
                echo "<p class='no-data'>No volunteers registered for this event yet.</p>";
            }

            echo "</div>";
        }
    } else {
        echo "<p class='no-data'>No events found.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>

    <!-- Back to Home Button -->
    <a href="option_event.html" class="back-button">Back to Previous Page</a>
</div>

</body>
</html>
