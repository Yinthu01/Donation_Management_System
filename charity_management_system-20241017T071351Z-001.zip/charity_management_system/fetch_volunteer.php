<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Details</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #fbc2eb, #a6c0fe); /* Gradient background */
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #e74c3c; /* Red color for headings */
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-out;
        }
        .search-bar {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-bar input {
            padding: 10px;
            width: 80%;
            max-width: 500px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .search-bar input:focus {
            border-color: #e74c3c; /* Red border on focus */
            outline: none;
        }
        .search-bar button {
            padding: 10px 20px;
            border: none;
            background-color: #e74c3c; /* Red color for button */
            color: #fff;
            border-radius: 8px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }
        .search-bar button:hover {
            background-color: #c0392b; /* Darker red on hover */
            transform: scale(1.05);
        }
        .stats-box {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
            border: 2px solid #e74c3c; /* Red border */
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stats-box:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .stats-box h2 {
            color: #e74c3c; /* Red color for stats headings */
            margin-bottom: 10px;
        }
        .volunteer {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .volunteer:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .volunteer h2 {
            color: #e74c3c; /* Red color for volunteer names */
            margin-top: 0;
            font-size: 1.8rem;
            transition: color 0.3s;
        }
        .volunteer:hover h2 {
            color: #c0392b; /* Darker red on hover */
        }
        .volunteer p {
            margin: 10px 0;
            font-size: 1rem;
            color: #555;
        }
        .events {
            border-top: 4px solid #e74c3c; /* Red border on top */
            margin-top: 20px;
            padding-top: 20px;
        }
        .events h3 {
            color: #e74c3c; /* Red color for events heading */
            font-size: 1.5rem;
            transition: color 0.3s;
        }
        .events:hover h3 {
            color: #c0392b; /* Darker red on hover */
        }
        .events ul {
            list-style-type: none;
            padding: 0;
        }
        .events li {
            background: #fff;
            border-radius: 8px;
            margin: 10px 0;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, transform 0.3s;
        }
        .events li:hover {
            background-color: #f7f7f7;
            transform: scale(1.02);
        }
        .no-data {
            text-align: center;
            font-style: italic;
            color: #666;
            font-size: 1.2rem;
        }
        .back-home {
            display: block;
            width: fit-content;
            margin: 20px auto;
            padding: 10px 20px;
            text-align: center;
            background-color: #e74c3c; /* Red color for button */
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            font-size: 1rem;
            transition: background-color 0.3s, transform 0.3s;
        }
        .back-home:hover {
            background-color: #c0392b; /* Darker red on hover */
            transform: scale(1.05);
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Volunteer Details</h1>

    <div class="search-bar">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search by name, email, or phone" value="<?php echo htmlspecialchars($_GET['search'] ?? '', ENT_QUOTES); ?>">
            <button type="submit">Search</button>
        </form>
    </div>

    <?php
    // Include the database connection file
    require_once 'db.php';

    // Fetch total number of volunteers
    $total_volunteers_sql = "SELECT COUNT(*) as total FROM volunteers";
    $total_volunteers_result = $conn->query($total_volunteers_sql);
    $total_volunteers = $total_volunteers_result->fetch_assoc()['total'];

    // Fetch total number of volunteers who have not participated in any events
    $no_event_volunteers_sql = "
        SELECT COUNT(v.volunteer_id) as no_event_volunteers
        FROM volunteers v
        LEFT JOIN event_volunteers ev ON v.volunteer_id = ev.volunteer_id
        WHERE ev.volunteer_id IS NULL
    ";
    $no_event_volunteers_result = $conn->query($no_event_volunteers_sql);
    $no_event_volunteers = $no_event_volunteers_result->fetch_assoc()['no_event_volunteers'];

    // Display volunteer statistics
    echo "<div class='stats-box'>";
    echo "<h2>Total Volunteers: " . $total_volunteers . "</h2>";
    echo "</div>";
    echo "<div class='stats-box'>";
    echo "<h2>Volunteers Not Registered for Any Events: " . $no_event_volunteers . "</h2>";
    echo "</div>";

    // Search functionality
    $search = $_GET['search'] ?? '';
    $search = $conn->real_escape_string($search);

    // Fetch all volunteers from the database with search filter
    $sql = "SELECT * FROM volunteers WHERE 
            CONCAT(first_name, ' ', last_name) LIKE '%$search%' OR 
            email LIKE '%$search%' OR 
            phone LIKE '%$search%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $volunteer_id = $row['volunteer_id'];
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];
            $email = $row['email'];
            $phone = $row['phone'];
            
            // Display volunteer details
            echo "<div class='volunteer'>";
            echo "<h2>Volunteer: " . htmlspecialchars($first_name) . " " . htmlspecialchars($last_name) . "</h2>";
            echo "<p>Email: " . htmlspecialchars($email) . "</p>";
            echo "<p>Phone: " . htmlspecialchars($phone) . "</p>";
            
            // Prepare and execute SQL to fetch events for this volunteer
            $event_sql = "
                SELECT e.event_name, e.event_date, e.location, e.description 
                FROM events e
                JOIN event_volunteers ev ON e.event_id = ev.event_id
                WHERE ev.volunteer_id = ?
            ";
            $stmt = $conn->prepare($event_sql);
            $stmt->bind_param("i", $volunteer_id);
            $stmt->execute();
            $event_result = $stmt->get_result();

            // Display events the volunteer is registered for
            if ($event_result->num_rows > 0) {
                echo "<div class='events'>";
                echo "<h3>Registered Events:</h3>";
                echo "<ul>";
                while ($event = $event_result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($event['event_name']) . 
                    " - Date: " . htmlspecialchars($event['event_date']) . 
                    " - Location: " . htmlspecialchars($event['location']) . 
                    " - Description: " . htmlspecialchars($event['description']) . "</li>";
                }
                echo "</ul>";
                echo "</div>";
            } else {
                echo "<p class='no-data'>This volunteer is not registered for any events.</p>";
            }
            
            echo "</div>";
        }
    } else {
        echo "<p class='no-data'>No volunteers found.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>

    <a href="option_event.html" class="back-home">Back to Previous Page</a>
</div>

</body>
</html>
