<?php
include('db.php');

// Handle delete action if 'id' parameter is passed
if (isset($_GET['delete_id'])) {
    $volunteer_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM event_volunteers WHERE volunteer_id='$volunteer_id'";

    if ($conn->query($delete_sql) === TRUE) {
        $message = "Volunteer deleted successfully.";
    } else {
        $message = "Error deleting volunteer: " . $conn->error;
    }
}

// Handle add action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
    $event_id = $_POST['event_id'];
    $volunteer_id = $_POST['volunteer_id'];
    $registration_date = $_POST['registration_date'];

    // Check if event_id exists
    $stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $eventResult = $stmt->get_result();

    // Check if volunteer_id exists
    $stmt = $conn->prepare("SELECT * FROM volunteers WHERE volunteer_id = ?");
    $stmt->bind_param("i", $volunteer_id);
    $stmt->execute();
    $volunteerResult = $stmt->get_result();

    if ($eventResult->num_rows > 0 && $volunteerResult->num_rows > 0) {
        // Both event and volunteer exist, proceed to insert the record
        $stmt = $conn->prepare("INSERT INTO event_volunteers (event_id, volunteer_id, registration_date)
                                VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $event_id, $volunteer_id, $registration_date);

        if ($stmt->execute()) {
            $message = "New volunteer added successfully.";
        } else {
            $message = "Error adding volunteer: " . $stmt->error;
        }
    } else {
        $message = "Error: Event ID or Volunteer ID does not exist. Please provide valid IDs.";
    }
}

// Handle edit action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
    $event_id = $_POST['edit_event_id'];
    $volunteer_id = $_POST['edit_volunteer_id'];
    $registration_date = $_POST['edit_registration_date'];

    $stmt = $conn->prepare("UPDATE event_volunteers 
                            SET registration_date = ?
                            WHERE event_id = ? AND volunteer_id = ?");
    $stmt->bind_param("sii", $registration_date, $event_id, $volunteer_id);

    if ($stmt->execute()) {
        $message = "Volunteer updated successfully.";
    } else {
        $message = "Error updating volunteer: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Event Volunteers</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        .container {
            flex: 1;
        }
        /* Navbar Styling */
.navbar {
    background-color: #343a40;
    padding: 1rem;
}

.navbar-nav {
    margin-left: auto; /* Pushes the navigation items to the right */
}

.navbar-brand {
    color: #fff;
    font-size: 1.5rem;
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #ddd;
    margin-left: 20px;
    position: relative;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
    margin-left: 20px;
    margin-right: 10px;
}

/* Hover effect for normal nav links */
.navbar-nav .nav-link:hover {
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    transition: 0.3s;

}

/* Dropdown specific styling */
.navbar-nav .dropdown-menu {
    background-color: #444;
    border: none;
    border-radius: 10px;
    padding: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    margin-top: 10px;
}

.navbar-nav .dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
}

/* Dropdown item styling */
.navbar-nav .dropdown-item {
    color: #ddd;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

/* Hover effect for dropdown items */
.navbar-nav .dropdown-item:hover {
    background-color: #ff7f50;
    color: white;
    transform: scale(1.05);
}

/* Arrow styling for the dropdown toggle */
.navbar-nav .dropdown-toggle::after {
    display: none;
}

.navbar-nav .dropdown-toggle:after {
    content: '\25BC'; /* Unicode for a down arrow */
    margin-left: 5px;
    font-size: 0.8rem;
    color: #ddd;
    transition: transform 0.3s ease;
}

/* Rotate arrow when dropdown is open */
.navbar-nav .dropdown-toggle[aria-expanded="true"]::after {
    transform: rotate(180deg);
}

        .page-header {
            background-color: #f8f9fa;
            padding: 30px;
            text-align: center;
        }
        h1 {
            color: #343a40;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .page-header p {
            color: #6c757d;
            font-size: 1.2rem;
        }
        body {
            background-color: #f8f9fa;
            margin-bottom: 20px; /* Space for footer */
        }
        .container {
            max-width: 1200px;
        }
        .table-container {
            margin-top: 20px;
            background-color: #ffffff; /* White background for the table container */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            padding: 20px; /* Add some padding */
        }
        .table {
            margin-bottom: 0; /* Remove bottom margin to align with container */
            border-collapse: separate; /* Apply spacing between cells */
            border-spacing: 0 10px; /* Add vertical spacing between rows */
        }
        .table th, .table td {
            text-align: center; /* Center text in cells */
            vertical-align: middle; /* Center text vertically */
        }
        .table th {
            background-color: #007bff; /* Primary color for header */
            color: #ffffff; /* White text color */
            font-weight: bold; /* Bold header text */
            padding: 12px; /* Add padding to header cells */
        }
        .table td {
            background-color: #ffffff; /* White background for cells */
            padding: 12px; /* Add padding to cells */
            border-bottom: 1px solid #ddd; /* Subtle border for separation */
        }
        .table tr:nth-child(even) td {
            background-color: #f9f9f9; /* Alternate row background */
        }
        .table tbody tr:hover {
            background-color: #f1f1f1; /* Highlight row on hover */
            cursor: pointer; /* Pointer cursor on hover */
        }
        .btn {
            font-size: 16px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #28a745, #218838);
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin-left: auto;  /* Pushes the button to the right side */
        }
        .modal-content {
            border-radius: 8px;
        }
        .modal-header, .modal-footer {
            border: none;
        }
        .modal-title {
            font-size: 18px;
        }
        .alert {
            margin-top: 20px;
        }
        .footer {
            background-color: #343a40;
            color: white;
            padding: 15px;
            text-align: center;
            position: relative;
            width: 100%;
            margin-top: 40px;/* Ensure space between content and footer */
        }
        .footer-links {
            margin-top: 10px;
        }
        .footer-links a {
            color: #ddd;
            margin: 0 10px;
            text-decoration: none;
        }
        .footer-links a:hover {
            color: #fff;
            transition: 0.3s;
        }
    </style>
</head>
<body>
    
<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-hands-helping"></i> Charity Management</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_donors.php"><i class="fas fa-users"></i> Donors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php"><i class="fas fa-hand-holding-usd"></i> Donations</a>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-calendar-alt"></i> More
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
    <a class="dropdown-item" href="event.php">Event</a>
    <a class="dropdown-item" href="volunteer.php">Volunteer</a>
    <a class="dropdown-item" href="event_volunteers.php">Volunteer_event</a>
</div>

                </li>
            </ul>
        </div>
    </div>
</nav>

    <!-- Display message if any -->
    <?php if (isset($message)): ?>
        <div class="alert alert-info text-center">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Page Header -->
    <div class="page-header">
        <h1>Manage Volunteers and Respected Events</h1>
        <p>View, add, edit, and delete volunteers for each event.</p>
    </div>

    <div class="container">
        <!-- Add Donor Button -->
        <div class="d-flex justify-content-end mb-3">
            <button class="btn btn-primary" data-toggle="modal" data-target="#addModal">Add Volunteers and Respected Events</button>
        </div>

        <div class="table-container">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Event ID</th>
                        <th>Event Name</th>
                        <th>Volunteer ID</th>
                        <th>Volunteer Name</th>
                        <th>Registration Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT ev.event_id, e.event_name, v.volunteer_id, v.first_name, v.last_name, ev.registration_date
                            FROM event_volunteers ev
                            JOIN events e ON ev.event_id = e.event_id
                            JOIN volunteers v ON ev.volunteer_id = v.volunteer_id";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . $row['event_id'] . "</td>
                                    <td>" . $row['event_name'] . "</td>
                                    <td>" . $row['volunteer_id'] . "</td>
                                    <td>" . $row['first_name'] . " " . $row['last_name'] . "</td>
                                    <td>" . $row['registration_date'] . "</td>
                                    <td>
                                        <button class='btn btn-success btn-sm edit-btn'
                                                data-event_id='" . $row['event_id'] . "'
                                                data-volunteer_id='" . $row['volunteer_id'] . "'
                                                data-registration_date='" . $row['registration_date'] . "'
                                                data-toggle='modal' 
                                                data-target='#editModal'>
                                            <i class='fas fa-edit'></i> Edit
                                        </button>
                                        <a href='manage_volunteers.php?delete_id=" . $row['volunteer_id'] . "' 
                                           class='btn btn-danger btn-sm'
                                           onclick='return confirm(\"Are you sure you want to delete this volunteer?\")'>
                                            <i class='fas fa-trash-alt'></i> Delete
                                        </a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No volunteers found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add Volunteer to Event</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="event_id">Event ID</label>
                            <input type="number" class="form-control" id="event_id" name="event_id" required>
                        </div>
                        <div class="form-group">
                            <label for="volunteer_id">Volunteer ID</label>
                            <input type="number" class="form-control" id="volunteer_id" name="volunteer_id" required>
                        </div>
                        <div class="form-group">
                            <label for="registration_date">Registration Date</label>
                            <input type="date" class="form-control" id="registration_date" name="registration_date" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="add" class="btn btn-primary">Add Volunteer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Volunteer Registration</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="">
                    <div class="modal-body">
                        <input type="hidden" id="edit_event_id" name="edit_event_id">
                        <input type="hidden" id="edit_volunteer_id" name="edit_volunteer_id">
                        <div class="form-group">
                            <label for="edit_registration_date">Registration Date</label>
                            <input type="date" class="form-control" id="edit_registration_date" name="edit_registration_date" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="edit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2024 Charity Management. All Rights Reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a> | <a href="#">Contact Us</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        // Populate edit modal with data
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', () => {
                const event_id = button.getAttribute('data-event_id');
                const volunteer_id = button.getAttribute('data-volunteer_id');
                const registration_date = button.getAttribute('data-registration_date');

                document.getElementById('edit_event_id').value = event_id;
                document.getElementById('edit_volunteer_id').value = volunteer_id;
                document.getElementById('edit_registration_date').value = registration_date;
            });
        });
    </script>
</body>
</html>
