<?php
// Include database connection
include('db.php');

// Check if the volunteer ID is set in the URL
if (isset($_GET['id'])) {
    $volunteer_id = $_GET['id'];

    // Perform the delete query
    $sql = "DELETE FROM event_volunteers WHERE volunteer_id = '$volunteer_id' and event_id = '$event_id'";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the main page with success message
        header("Location: event_volunteers.php?delete_success=true");
        exit();
    } else {
        // Redirect back with error message if delete failed
        header("Location: event_volunteers.php?delete_error=true");
        exit();
    }
} else {
    // If no ID is provided, redirect back
    header("Location: event_volunteers.php");
    exit();
}
?>
