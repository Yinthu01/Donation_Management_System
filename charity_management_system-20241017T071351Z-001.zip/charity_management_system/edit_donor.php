<?php
include 'db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $donor_id = mysqli_real_escape_string($conn, $_POST['donor_id']);
    
    // Initialize variables
    $first_name = !empty($_POST['first_name']) ? mysqli_real_escape_string($conn, $_POST['first_name']) : NULL;
    $last_name = !empty($_POST['last_name']) ? mysqli_real_escape_string($conn, $_POST['last_name']) : NULL;
    $email = !empty($_POST['email']) ? mysqli_real_escape_string($conn, $_POST['email']) : NULL;
    $phone = !empty($_POST['phone']) ? mysqli_real_escape_string($conn, $_POST['phone']) : NULL;
    $donor_type = !empty($_POST['donor_type']) ? mysqli_real_escape_string($conn, $_POST['donor_type']) : NULL;
    $organization_name = !empty($_POST['organization_name']) ? mysqli_real_escape_string($conn, $_POST['organization_name']) : NULL;

    // Build query dynamically
    $update_fields = [];

    if ($first_name !== NULL) {
        $update_fields[] = "first_name = '$first_name'";
    }
    if ($last_name !== NULL) {
        $update_fields[] = "last_name = '$last_name'";
    }
    if ($email !== NULL) {
        $update_fields[] = "email = '$email'";
    }
    if ($phone !== NULL) {
        $update_fields[] = "phone = '$phone'";
    }
    if ($donor_type !== NULL) {
        $update_fields[] = "donor_type = '$donor_type'";
    }
    if ($organization_name !== NULL) {
        $update_fields[] = "organization_name = '$organization_name'";
    }

    if (count($update_fields) > 0) {
        // Join the fields into a string for the SQL query
        $update_query = implode(", ", $update_fields);

        // Final SQL query
        $query = "UPDATE donors SET $update_query WHERE donor_id = '$donor_id'";

        // Execute the query
        if (mysqli_query($conn, $query)) {
            header("Location: manage_donors.php");
            exit(); // Make sure to exit after a header redirect
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "No fields to update.";
    }

    mysqli_close($conn);
}
?>
