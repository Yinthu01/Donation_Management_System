<?php
session_start();
include 'db.php'; 
$result = $conn->query("SELECT * FROM donors"); // Include the database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Donors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Navbar Styling */
.navbar {
    background-color: #343a40;
    padding: 1rem;
}

.navbar-brand {
    color: #fff;
    font-size: 1.5rem;
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #ddd;
    margin-left: 20px;
    position: relative;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
}

/* Hover effect for normal nav links */
.navbar-nav .nav-link:hover {
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    transition: 0.3s;
}

/* Dropdown specific styling */
.navbar-nav .dropdown-menu {
    background-color: #444;
    border: none;
    border-radius: 10px;
    padding: 10px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease-in-out;
    margin-top: 10px;
}

.navbar-nav .dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
}

/* Dropdown item styling */
.navbar-nav .dropdown-item {
    color: #ddd;
    padding: 10px 20px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

/* Hover effect for dropdown items */
.navbar-nav .dropdown-item:hover {
    background-color: #ff7f50;
    color: white;
    transform: scale(1.05);
}

/* Arrow styling for the dropdown toggle */
.navbar-nav .dropdown-toggle::after {
    display: none;
}

.navbar-nav .dropdown-toggle:after {
    content: '\25BC'; /* Unicode for a down arrow */
    margin-left: 5px;
    font-size: 0.8rem;
    color: #ddd;
    transition: transform 0.3s ease;
}

/* Rotate arrow when dropdown is open */
.navbar-nav .dropdown-toggle[aria-expanded="true"]::after {
    transform: rotate(180deg);
}

        .page-header {
            background-color: #f8f9fa;
            padding: 30px;
            text-align: center;
        }
        .page-header h1 {
            color: #343a40;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .page-header p {
            color: #6c757d;
            font-size: 1.2rem;
            margin-bottom: 20px;
        }
        h1 {
            color: #343a40;
            font-weight: bold;
            margin-top: 30px;
            text-align: center;
        }
        .container {
            margin-bottom: 1px; /* Space between table and footer */
        }
        .btn-add {
            background: linear-gradient(135deg, #28a745, #218838);
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin-right: 80px;
        }
        .btn-add:hover {
            background: linear-gradient(135deg, #218838, #28a745);
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }
        .btn-add {
            padding: 8px 16px; /* Adjust padding if needed */
            margin-right: 100px;
        }
        .btn-edit, .btn-delete {
            border: none;
            color: white;
            font-size: 0.9rem;
            border-radius: 5px;
            padding: 5px 10px;
            transition: all 0.3s ease;
        }
        .btn-edit {
            background-color: #28a745;
        }
        .btn-edit:hover {
            background-color: #218838;
        }
        .btn-delete {
            background-color: #dc3545;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
        .table-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            margin-top: 20px; /* Space between button and table */
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
            width: 100%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* 3D effect */
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
        .table thead th {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 20px;
            text-align: center;
            bottom: 0;
            width: 100%;
            margin-top: 40px;/* Ensure space between content and footer */
        }
        .footer-links {
            margin-top: 10px;
        }
        .footer-links a {
            color: #ddd;
            margin: 0 10px;
            text-decoration: none;
        }
        .footer-links a:hover {
            color: #fff;
            transition: 0.3s;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="fas fa-hands-helping"></i> Charity Management</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_donors.php"><i class="fas fa-users"></i> Donors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php"><i class="fas fa-hand-holding-usd"></i> Donations</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-calendar-alt"></i> More
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="event.php">Event</a></li>
                        <li><a class="dropdown-item" href="volunteer.php">Volunteer</a></li>
                        <li><a class="dropdown-item" href="event_volunteers.php">Volunteer_event</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>


<!-- Main content -->
<div class="container">
    <h1>Manage Donors</h1>

    <!-- Add Donor Button -->
    <div class="text-end">
        <button class="btn btn-add btn-sm" data-bs-toggle="modal" data-bs-target="#addDonorModal">Add Donor</button>
    </div>

    <!-- Table of Donors -->
    <div class="table-container">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Donor ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Donor Type</th>
                    <th>Organization Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($donor = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$donor['donor_id']}</td>
                            <td>{$donor['first_name']}</td>
                            <td>{$donor['last_name']}</td>
                            <td>{$donor['email']}</td>
                            <td>{$donor['phone']}</td>
                            <td>{$donor['donor_type']}</td>
                            
                            <td>" . ($donor['donor_type'] === 'organization' ? $donor['organization_name'] : 'N/A') . "</td>
                            <td>
                                <button class='btn btn-edit btn-sm' data-bs-toggle='modal' data-bs-target='#editDonorModal'
                                    data-id='{$donor['donor_id']}'
                                    data-firstname='{$donor['first_name']}'
                                    data-lastname='{$donor['last_name']}'
                                    data-email='{$donor['email']}'
                                    data-phone='{$donor['phone']}'
                                    data-type='{$donor['donor_type']}'
                                    data-orgname='{$donor['organization_name']}'>
                                    <i class='fas fa-edit'></i> Edit
                                </button>
                                
                                <a href='delete_donor.php?donor_id={$donor['donor_id']}' class='btn btn-delete btn-sm' onclick='return confirm(\"Are you sure you want to delete this donor?\");'><i class='fas fa-trash'></i> Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No donors found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Donor Modal -->
<!-- Add Donor Modal -->
<div class="modal fade" id="addDonorModal" tabindex="-1" aria-labelledby="addDonorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="add_donor.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDonorModalLabel">Add Donor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form fields -->
                    <div class="mb-3">
                        <label for="first_name" class="form-label">First Name (Optional)</label>
                        <input type="text" class="form-control" id="first_name" name="first_name">
                    </div>
                    <div class="mb-3">
                        <label for="last_name" class="form-label">Last Name (Optional)</label>
                        <input type="text" class="form-control" id="last_name" name="last_name">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" required>
                    </div>
                    <div class="mb-3">
                        <label for="donor_type" class="form-label">Donor Type</label>
                        <select class="form-select" id="donor_type" name="donor_type" required>
                            <option value="individual">Individual</option>
                            <option value="organization">Organization</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="organization_name" class="form-label">Organization Name (Optional)</label>
                        <input type="text" class="form-control" id="organization_name" name="organization_name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Donor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Donor Modal -->
<div class="modal fade" id="editDonorModal" tabindex="-1" aria-labelledby="editDonorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="edit_donor.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDonorModalLabel">Edit Donor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form fields, prefilled with JavaScript -->
                    <input type="hidden" id="edit_donor_id" name="donor_id">
                    <div class="mb-3">
                        <label for="edit_first_name" class="form-label">First Name (Optional)</label>
                        <input type="text" class="form-control" id="edit_first_name" name="first_name">
                    </div>
                    <div class="mb-3">
                        <label for="edit_last_name" class="form-label">Last Name (Optional)</label>
                        <input type="text" class="form-control" id="edit_last_name" name="last_name">
                    </div>
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="edit_phone" name="phone" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_donor_type" class="form-label">Donor Type</label>
                        <select class="form-select" id="edit_donor_type" name="donor_type" required>
                            <option value="individual">Individual</option>
                            <option value="organization">Organization</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_organization_name" class="form-label">Organization Name (Optional)</label>
                        <input type="text" class="form-control" id="edit_organization_name" name="organization_name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Donor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Footer -->
<footer>
    <div class="container">
        <p>&copy; 2024 Charity Donation Management. All Rights Reserved.</p>
        <div class="footer-links">
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="privacy.php">Privacy Policy</a>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const editDonorModal = document.getElementById('editDonorModal');
    editDonorModal.addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const donorId = button.getAttribute('data-id');
        const firstName = button.getAttribute('data-firstname');
        const lastName = button.getAttribute('data-lastname');
        const email = button.getAttribute('data-email');
        const phone = button.getAttribute('data-phone');
        const donorType = button.getAttribute('data-type');
        const organizationName = button.getAttribute('data-orgname');

        document.getElementById('edit_donor_id').value = donorId;
        document.getElementById('edit_first_name').value = firstName;
        document.getElementById('edit_last_name').value = lastName;
        document.getElementById('edit_email').value = email;
        document.getElementById('edit_phone').value = phone;
        document.getElementById('edit_donor_type').value = donorType;
        document.getElementById('edit_organization_name').value = organizationName;
    });
});
</script>

</body>
</html>
