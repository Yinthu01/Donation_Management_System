<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "INSERT INTO volunteers (first_name, last_name, email, phone) VALUES ('$first_name', '$last_name', '$email', '$phone')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        header("Location: volunteer.php");
    } else {
        die("Insert query failed: " . mysqli_error($conn));
    }
}
?>
