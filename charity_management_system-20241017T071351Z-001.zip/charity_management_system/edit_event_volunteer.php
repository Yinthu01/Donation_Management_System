<?php
include('db.php');

// Fetch the volunteer data to edit
if (isset($_GET['id'])) {
    $volunteer_id = $_GET['id'];

    $sql = "SELECT * FROM event_volunteers WHERE volunteer_id = '$volunteer_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $event_id = $row['event_id'];
        $registration_date = $row['registration_date'];
    } else {
        echo "No record found for the given Volunteer ID.";
        exit;
    }
}

// Update the volunteer details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = $_POST['event_id'];
    $volunteer_id = $_POST['volunteer_id'];
    $registration_date = $_POST['registration_date'];

    $sql = "UPDATE event_volunteers SET event_id = '$event_id', registration_date = '$registration_date'
            WHERE volunteer_id = '$volunteer_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Volunteer details updated successfully.";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Event Volunteer</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Event Volunteer</h2>
        <form method="POST" action="edit_event_volunteer.php?id=<?php echo $volunteer_id; ?>">
            <div class="form-group">
                <label for="event_id">Event ID</label>
                <input type="text" class="form-control" id="event_id" name="event_id" value="<?php echo $event_id; ?>" required>
            </div>
            <div class="form-group">
                <label for="volunteer_id">Volunteer ID</label>
                <input type="text" class="form-control" id="volunteer_id" name="volunteer_id" value="<?php echo $volunteer_id; ?>" readonly>
            </div>
            <div class="form-group">
                <label for="registration_date">Registration Date</label>
                <input type="date" class="form-control" id="registration_date" name="registration_date" value="<?php echo $registration_date; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Volunteer</button>
        </form>
        <a href="event_volunteers.php" class="btn btn-secondary mt-3">Back</a>
    </div>
</body>
</html>
